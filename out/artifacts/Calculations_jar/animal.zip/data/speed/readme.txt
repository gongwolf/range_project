
1. Compile and pack the files

javac *.java
jar cvf Calculations.jar *.class

2. Run the file
java -cp Calculations.jar AnimalProject

